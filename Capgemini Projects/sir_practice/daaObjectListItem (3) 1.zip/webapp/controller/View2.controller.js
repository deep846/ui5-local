sap.ui.define([
		"namespace/controller/BaseController"
		], function(Controller) {
			"use strict";
		
			return Controller.extend("namespace.controller.View2", {


            onPressView1:function(){
            	var oModle=this.getView().getModel("toolsModel")
            	var oApp=this.getView().getParent();
            	oApp.to("idView");
            }






			});
			
			});