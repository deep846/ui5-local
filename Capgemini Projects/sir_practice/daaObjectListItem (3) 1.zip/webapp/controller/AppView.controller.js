sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("namespace.controller.AppView", {

	
			onInit: function() {
				
				var oApp=this.getView().byId("idApp"); 
				
				var oView1= new sap.ui.core.mvc.XMLView({
					id:"idView",
					viewName:"namespace.view.View1"
				});
				var oView2= new sap.ui.core.mvc.XMLView({
					id:"idView2",
					viewName:"namespace.view.View2"
				});
				
				oApp.addPage(oView1);
				oApp.addPage(oView2);
		
			}

	

	});

});