sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"namespace/models/model"
], function(Controller,model) {
	"use strict";

	return Controller.extend("namespace.controller.BaseController", {

	
			onInit: function() {
			// var oModel=model.createModel("models/mockData/toolsData.json");
		 //        sap.ui.getCore().setModel(oModel,"toolsModel");
			
		
			}

	

	});

});