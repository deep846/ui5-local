sap.ui.define([
		"namespace/controller/BaseController",
		"sap/ui/core/Fragment"
		], function(Controller,Fragment) {
			"use strict";
		
			return Controller.extend("namespace.controller.View2", {
			
				
				onConfirm:function(oEvent){
					var oItem=oEvent.getParameter("selectedItem");
					var sItem=oItem.mProperties.value;
					var sInpt=sap.ui.getCore().byId(this.id);
					sInpt.setValue(sItem);

				},

             onF4Help:function(oEvent){
             	this.id=oEvent.getSource().getId();
             	
             	if(!this.oFragment){
             		this.oFragment=Fragment.load({
             			name:"namespace.fragments.popup",
             			controller:this 
             		}).then(function(oDialog){
             			this.oFragment=oDialog;
             			this.getView().addDependent(this.oFragment);
             			this.oFragment.open();
             			
             		}.bind(this));
             		
             	}else{
             		this.oFragment.open();
             	}
             },
            onPressView1:function(){
            	var oModle=this.getView().getModel("toolsModel");
            	var oApp=this.getView().getParent();
            	oApp.to("idView");
            }
             





			});
			
			});